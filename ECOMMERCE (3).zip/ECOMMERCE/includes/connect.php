<?php

$con=mysqli_connect('localhost','root','','mystore');
if(!$con){
     die(mysqli_error($con));
 // echo "Connected to successful";
}// else{   die(mysqli_error($con));}



?>